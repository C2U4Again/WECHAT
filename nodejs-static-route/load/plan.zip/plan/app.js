// app.js
App({

    onLaunch() {
    

        // //云开发环境的初始化
        // wx.cloud.init({
        //   env:'cloud1-0g6ikz47c348f678'
        // })
    
    
    
      },
// 全局字体大小
globalData:{
   
    fs: 40,
    userInfo: null


},



})
