Page({

  /**
   * 页面的初始数据
   */
  data: {
    monster: {//假设原数据
      '1': {
        '独眼蝙蝠': {
          'id': 1,
          'name': '独眼蝙蝠',
          'select': false,
        },
        '彭哆菇': {
          'id': 2,
          'name': '彭哆菇',
          'select': false,
        },
        '象牙甲虫': {
          'id': 3,
          'name': '象牙甲虫',
          'select': false,
        },

      },
      '2': {
        '魔导战甲': {
          'id': 4,
          'name': '魔导战甲',
          'select': false,
        },
        '邪恶的南瓜': {
          'id': 5,
          'name': '邪恶的南瓜',
          'select': false,
        },
        '巨剑浪人': {
          'id': 6,
          'name': '巨剑浪人',
          'select': false,
        },
      }
    },
    cur_index: 0,
    num: 0,
  },

  /**
   * 当选中时触发
   * @param {*} e
   */
  OnSelect(e) {
    let { id } = e.currentTarget.dataset
    let { monster } = this.data

    console.log("当前点击:", id)

    //根据id,将当前选中的id的select设置为true
    for (let i in monster) {
      for (let o in monster[i]) {
        if (monster[i][o].id == id) {
          monster[i][o].select = true
        } else {
          monster[i][o].select = false
        }
      }
    }

    //渲染数据
    this.setData({
      monster
    })

  },


    itemClick: function (e) {
      console.log("当前e点击:", e.currentTarget.dataset.num)
        this.setData({
            num: 0
        })
        this.setData({
            num: e.currentTarget.dataset.num
        })
        
    }
})
