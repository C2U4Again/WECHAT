Page({
  data: {
  color: "red"
  },
  clickRed: function () {
  this.setData({
   color: "red"
  })
  },
  clickgreen: function () {
  this.setData({
   color: "green"
  })
  }
 })