// pages/book0/book0.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        infoList:[],
        fs:0,
       chap: 1, //显示隐藏,
       current_index:0,
       dataurl:'',
       origList:[],
       content:1,
       showView: true,
       bookID:[],
       abc:[],
       sum:'',//查询条数,
       total1:0
  
    },
  
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        var that = this;
        var dataurl=options.dataurl
        var total1=options.total
        var bookID=20
        var num1=1;//wx.getStorageSync(key)，获取本地缓存
    
        
        that.setData({
            current_index:1,
            dataurl:dataurl,
            bookID:bookID,
            total1:total1
  
        })
        //调用数据结束
        wx.request({
      
          url: dataurl,
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          },
          success: function (res) {
            that.data.origList = res.data;
            //console.log(that.data.origList);
            that.setData({
            infoList: res.data,
            origList:that.data.origList,
            
            })
          },
  
          fail:function(err)
          {
              console.log(err)
          }
      
            
        })
    },

    search:function (e) {

      var that = this;
      var Items = [];
  
  Items =  that.data.origList.filter((item)=>{

     
      if((item.name.indexOf(e.detail.value) != -1) || (item.join.indexOf(e.detail.value) != -1)){
      
       return item
          
      }
      else{
          return
      }
  })
   
   that.setData({
     hero:Items
   })
   
},
ni(e){
  var co=e.currentTarget.dataset.letter
  
  this.setData({
    content: co,
    
  });
  wx.pageScrollTo({
    selector: '#'+co
    });
 },
  
   
  
  
  
  
  
  
  
  
  
  
  
  
  
    onUnload() {
  
    },
  
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
  
    },
  
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {
  
    },
  
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {
  
    }
  })
  
  