Page({
  data: {
  css: "0"
  },
  clickRed: function () {
  this.setData({
   css: "1"
  })
  },
  clickgreen: function () {
  this.setData({
   css: "2"
  })
  }
 })