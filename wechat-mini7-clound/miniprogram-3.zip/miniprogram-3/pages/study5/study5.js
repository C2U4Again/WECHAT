Page({
    data: {
        animationMain:null,//正面
        animationBack:null,//背面
        show:false,//控制下拉列表的显示隐藏，false隐藏、true显示
        selectData:['流行歌词','日语四级','英语托福','前端函数','自定义'],//下拉列表的数据
        index:0//选择的下拉列表下标
        
    },

    
        // 点击下拉显示框
        selectTap(){
        this.setData({
         show: !this.data.show
        });
        },
        // 点击下拉列表
        optionTap(e){
        let Index=e.currentTarget.dataset.index;//获取点击的下拉列表的下标
        this.setData({
         index:Index,
         show:!this.data.show
        })
    },
       

    rotateFn(e) {
        var id = e.currentTarget.dataset.id
        this.animation_main = wx.createAnimation({
          duration:400,
          timingFunction:'linear'
        })
        this.animation_back = wx.createAnimation({
          duration:400,
          timingFunction:'linear'
        })
        // 点击正面
   
        if (id==1) {
        this.animation_main.rotateY(180).step()
        this.animation_back.rotateY(0).step()
        this.setData({
            animationMain: this.animation_main.export(),
            animationBack: this.animation_back.export(),
        })
        }
        // 点击背面
        else{
        this.animation_main.rotateY(0).step()
        this.animation_back.rotateY(-180).step()
        this.setData({
            animationMain: this.animation_main.export(),
            animationBack: this.animation_back.export(),
        })
        }
    },
  
      //点击控制下拉框的展示、隐藏
      select:function(){
        var isSelect = this.data.isSelect
        this.setData({ isSelect:!isSelect})
      },
      //点击下拉框选项，选中并隐藏下拉框
      getType:function(e){
        let value = e.currentTarget.dataset.type
        this.setData({
          type:value ,
          isSelect: false,
        })
      },
    
  })